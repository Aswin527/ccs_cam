<!doctype html>
 <html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

 <head>
     <meta charset="utf-8">
     <meta name="viewport" content="width=device-width, initial-scale=1">

     <!-- CSRF Token -->
     <meta name="csrf-token" content="{{ csrf_token() }}">

     <title>@yield('meta_title')</title>
     <meta name="title" content="@yield('meta_title')">
     <meta name="keywords" content="@yield('meta_keywords')">
     <meta name="description" content="@yield('meta_description')">
     <link rel="icon" type="image/x-icon" href="/front_asset/assets/img/company-name.jpg">
     <meta property="og:title" content="@yield('meta_title')" />
     <meta property="og:description" content="@yield('meta_description')" />
     <meta property="og:url" content="{{ Request::fullUrl() }}" />
     <meta property="og:image" @yield('meta_image') />
     <meta property="og:type" content="website" />
     <meta property="og:locale" content="en_GB" />

     <meta name="twitter:card" content="summary_large_image" />
     <meta name="twitter:description" content="@yield('meta_description')" />
     <meta name="twitter:title" content="@yield('meta_title')" />
     <meta name="twitter:image" @yield('meta_image') />



     <!-- ==============================================
	CSS
	=============================================== -->
	<link rel="stylesheet" type="text/css" href="/front_asset/css/bootstrap.min.css" />
	<link rel="stylesheet" type="text/css" href="/front_asset/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="/front_asset/css/owl.carousel.min.css">
	<link rel="stylesheet" type="text/css" href="/front_asset/css/owl.theme.default.min.css">
	
	<!-- ==============================================
	Google Fonts
	=============================================== -->
	<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700,900' rel='stylesheet' type='text/css'>
	<link href='https://fonts.googleapis.com/css?family=Merriweather' rel='stylesheet' type='text/css'>
	
	<!-- ==============================================
	Custom Stylesheet
	=============================================== -->
	<link rel="stylesheet" type="text/css" href="/front_asset/css/style.css" />
	
    <script type="text/javascript" src="/front_asset/js/modernizr.min.js"></script>


     @yield('CSS')



 </head>

 <body>
 

 <div class="animationload">
		<div class="loader"></div>
	</div>

    <div class="navbar navbar-main navbar-fixed-top">
	
    <div class="container">
        <div class="row bg-white">
            <div class="topbar">
                <div class="col-sm-7 col-md-7">
                    <div class="info">
                        <div class="info-item">
                            <span class="fa fa-phone"></span> 7814724399  <span class="fa fa-phone"></span> 8146551994

                        </div>
                        <div class="info-item">
                            <span class="fa fa-clock-o"></span> Mon-Sat: 9.00-18.00
                        </div>
                        <div class="info-item">
                            <span class="fa fa-envelope-o"></span> <a href="mailto:info@pestco.com" title="">pestresolverchd@gmail.com</a>
                        </div>
                        
                    </div>
                </div>
                <div class="col-sm-5 col-md-5">
                    <div class="request-quote pull-right">
                        <a href="#" title="">REQUEST A QUOTE</a>
                    </div>
                </div>
            </div>
            
        </div>
    </div>

    <div class="container container-nav">
    
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.html">
                <img src="/front_asset/images/pest.jpeg" alt="" />
            </a>
        </div>
        
        <nav class="navbar-collapse collapse">
            <ul class="nav navbar-nav navbar-right">
                <li><a href="/">HOME</a></li>
                <li><a href="/about-us">ABOUT US</a></li>
                <li><a href="services.html">SERVICES</a></li>
                <li><a href="blog.html">BLOG</a></li>
                <li><a href="/contact">CONTACT</a></li>
                

            </ul>
        </nav>
        
    </div>
</div> 
       

     @yield('content')
     <!-- footer -->

     <div class="footer bgi-footer">
		
		<div class="container">
		
			<div class="row">
				<div class="col-sm-4 col-md-4">
					<div class="box-info">
						<div class="box-info-icon">
							<span class="fa fa-phone"></span>
						</div>
						<div class="box-info-body">
							<p>Have a question? call us now</p>
							<h4>7814724399</h4>
						</div>
					</div>
				</div>
				<div class="col-sm-4 col-md-4">
					<div class="box-info">
						<div class="box-info-icon">
							<span class="fa fa-clock-o"></span>
						</div>
						<div class="box-info-body">
							<p>We are open on</p>
							<h4>Mon - Fri 08:00 - 20:00</h4>
						</div>
					</div>
				</div>
				<div class="col-sm-4 col-md-4">
					<div class="box-info">
						<div class="box-info-icon">
							<span class="fa fa-phone"></span>
						</div>
						<div class="box-info-body">
							<p>Need support? Drop us an email</p>
							<h4><a href="mailto:pestresolverchd@gmail.com" title="">pestresolverchd@gmail.com</a></h4>
						</div>
					</div>
				</div>
				
			</div>
		
			<div class="row">
				<div class="col-sm-4 col-md-4">
					<div class="footer-item">
						<div class="footer-title">
							<h5>ABOUT PEST<span>CO</span></h5>
						</div>
						<p>Lorem ipsum dolor sit amet libero turpis non cras ligula id commodo aenean est in volutpat amet sodales porttitor bibendum facilisi.</p> 
					</div>
				</div>
				<div class="col-sm-4 col-md-4">
					<div class="footer-item">
						<div class="footer-title">
							<h5>SERVICES</h5>
						</div>
						<ul class="list">
							<li><a href="#" title="">Residential Pest Control</a></li>
							<li><a href="#" title="">Commercial Pest Control</a></li>
							<li><a href="#" title="">Pest Prevention</a></li>
						</ul>
					</div>
				</div>
				<div class="col-sm-4 col-md-4">
					<div class="footer-item">
						<div class="footer-title">
							<h5>COMPANY</h5>
						</div>
						<ul class="list">
							<li><a href="/about-us" title="">About Us</a></li>
							<li><a href="faq.html" title="">Faq</a></li>
							<li><a href="#" title="">Support</a></li>
							<li><a href="/contact" title="">Contact</a></li>
						</ul>
					</div>
				</div>
				
			</div>
		</div>
			
		<div class="fsosmed">
			<div class="container">
				<div class="row">
					<div class="col-sm-12 col-md-12">
						<p class="fsos">SOCIAL LINKS</p>
						<div class="footer-sosmed">
							<a href="#" title="">
								<div class="item">
									<i class="fa fa-facebook"></i>
								</div>
							</a>
							<a href="#" title="">
								<div class="item">
									<i class="fa fa-twitter"></i>
								</div>
							</a>
							<a href="#" title="">
								<div class="item">
									<i class="fa fa-pinterest"></i>
								</div>
							</a>
							<a href="#" title="">
								<div class="item">
									<i class="fa fa-google"></i>
								</div>
							</a>
							<a href="#" title="">
								<div class="item">
									<i class="fa fa-instagram"></i>
								</div>
							</a>
							<a href="#" title="">
								<div class="item">
									<i class="fa fa-linkedin"></i>
								</div>
							</a> 
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<div class="fcopy">
			<div class="container">
				<div class="row">
					<div class="col-sm-12 col-md-12">
						<p class="ftex">&copy; 2022 Pest Resolver Developed & Designed By  Sanjay - All Rights Reserved</p> 
					</div>
				</div>
			</div>
		</div>
		
	</div> 
        
        <script type="text/javascript" src="/front_asset/js/jquery.min.js"></script>
	<script type="text/javascript" src="/front_asset/js/jquery.superslides.js"></script>
	<script type='text/javascript' src='https://maps.google.com/maps/api/js?sensor=false&amp;ver=4.1.5'></script>
	
	<script type="text/javascript" src="/front_asset/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="/front_asset/js/owl.carousel.js"></script>
	<script type="text/javascript" src="/front_asset/js/bootstrap-hover-dropdown.min.js"></script>
	<!-- sendmail -->
	<script type="text/javascript" src="/front_asset/js/validator.min.js"></script>
	<script type="text/javascript" src="/front_asset/js/form-scripts.js"></script>
	
	<script type="text/javascript" src="/front_asset/js/script.js"></script>
 </body>

 </html>