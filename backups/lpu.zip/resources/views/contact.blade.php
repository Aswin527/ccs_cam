@extends('layouts.app')
@section('meta_title','contactus')
@section('meta_keywords','contactus')
@section('meta_description','contactus')
@section('content') 
<div class="section subbanner">
		<div class="container">
			<div class="row">
				<div class="col-sm-12 col-md-12">
					<div class="caption">CONTACT</div>
					<ol class="breadcrumb">
						<li><a href="#">Home</a></li>
						<li class="active">Contact</li>
					</ol>

				</div>
			</div>
		</div>
	</div>


  <div class="section contact">
		<div class="container">
			<div class="row">
					
				<div class="col-sm-6 col-md-6">
					
					<div class="section-title">
						<h3 class="lead">WHY PEST RESOLVER?</h3>
					</div>
					<p>Commodo enim aliquam suspendisse tortor cum diam commodo facilisis rutrum et duis nisl porttitor vel eleifend odio ultricies ut orci in adipiscing. Commodo enim aliquam suspendisse tortor cum diam commodo facilisis rutrum et duis nisl porttitor vel eleifend odio ultricies ut orci in adipiscing</p>
					<div class="contact-info">
						<div class="contact-info-item">
							<span class="fa fa-phone"></span>  8146551994
						</div>
						<div class="contact-info-item">
							<span class="fa fa-clock-o"></span> Mon-Sat: 9.00-18.00 
						</div>
						<div class="contact-info-item">
							<span class="fa fa-envelope"></span> <a href="mailto:pestresolverchd@gmail.com" title="">pestresolverchd@gmail.com</a>
						</div>
						
					</div>
				</div>
				<div class="col-sm-6 col-md-6">
					<div class="post-image">
						<img src="/front_asset/images/blog-4.jpg" alt="" class="img-responsive">
					</div>
				</div>
				
				<div class="col-sm-12 col-md-8 col-md-offset-2">
					
					<br /><br />
					<div class="section-title center">
						<h3 class="lead">SEND MESSAGE</h3>
					</div>
					<br /><br />
					<div class="blok quotes">
						<form action="#" class="form-contact shake" id="contactForm" data-toggle="validator" novalidate="true">
							<div class="form-group">
								<input type="text" class="form-control" id="name" placeholder="Enter Name *" required="">
								<div class="help-block with-errors"></div>
							</div>
							<div class="form-group">
								<input type="email" class="form-control" id="email" placeholder="Enter Email *" required="">
								<div class="help-block with-errors"></div>
							</div>
							<div class="form-group">
								 <textarea id="message" class="form-control" rows="4" placeholder="Enter Your Message *" required=""></textarea>
								<div class="help-block with-errors"></div>
							</div>
							<div class="form-group">
								<div id="success"></div>
								<button type="submit" class="btn btn-default disabled" style="pointer-events: all; cursor: pointer;">ASK A QUOTE</button>
							</div>
						</form>
						<div class="icon"><span class="fa fa-calendar"></span></div>	
					</div>
					
				</div>
				
			</div>
		</div>
		
		
		
	</div>
@endsection