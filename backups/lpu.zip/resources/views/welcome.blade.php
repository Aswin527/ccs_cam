@extends('layouts.app')
@section('meta_title','Pest Control')

@section('meta_image','/front_asset/images/logo-2.png')
@section('content')
   
<!-- BANNER -->
<div id="slides" class="section banner">
		<ul class="slides-container">
			<li>
				<img src="/front_asset/images/slide-1.jpg" alt="">
				<div class="carousel-caption">
					<div class="container">
						<div class="wrap-caption">
							<div class="caption-heading">
								<div class="color1">
									<span>WE ARE THE EXPERTS</span>
								</div>
								<div class="color2">
									<span>IN PEST CONTROL</span>
								</div>
							</div>
								
						</div>
					</div>
				</div>
			</li>
			<li>
				<img src="/front_asset/images/slide-2.jpg" alt="">
				<div class="carousel-caption">
					<div class="container">
						<div class="wrap-caption">
							<div class="caption-heading">
								<div class="color1">
									<span>PROTECT YOUR</span>
								</div>
								<div class="color2">
									<span>HOME TODAY</span>
								</div>
							</div>
						</div>
					</div>
				</div>
			</li>
			<li>
				<img src="/front_asset/images/slide-3.jpg" alt="">
				<div class="carousel-caption">
					<div class="container">
						<div class="wrap-caption">
							<div class="caption-heading">
								<div class="color1">
									<span>WE CARE ABOUT</span>
								</div>
								<div class="color2">
									<span>YOUR PEST INFESTATION</span>
								</div>
							</div>
						</div>
					</div>
				</div>
			</li>

		</ul>
	</div>

	<!-- SERVICES -->
	<div class="section feature">
		<div class="container">
			<div class="row">
				
				<div class="col-sm-8 col-md-8">
					<div class="row">
						<div class="col-sm-4 col-md-4">
							<div class="blok feature-item">
								<div class="image">
									<a href="services-detail.html" title=""><img src="/front_asset/images/about-1.jpg" alt="" class="img-responsive"></a>
								</div>
								<div class="item-body">
									<div class="description">
										<h5 class="blok-title">
											<a href="services-detail.html" title="">RESIDENTIAL PEST CONTROL</a>
										</h5>
										<p>Lorem ipsum dolor sit amet libero turpis non cras ligula id commodo aenean est in volutpat amet sodales porttitor bibendum facilisi.</p>
										
									</div>
									
								</div>
							</div>
						</div>
						<div class="col-sm-4 col-md-4">
							<div class="blok feature-item">
								<div class="image">
									<a href="services-detail.html" title=""><img src="/front_asset/images/about-2.jpg" alt="" class="img-responsive"></a>
								</div>
								<div class="item-body">
									<div class="description">
										<h5 class="blok-title">
											<a href="services-detail.html" title="">COMMERCIAL PEST CONTROL</a>
										</h5>
										<p>Lorem ipsum dolor sit amet libero turpis non cras ligula id commodo aenean est in volutpat amet sodales porttitor bibendum facilisi.</p>
										
									</div>
									
								</div>
							</div>
						</div>
						<div class="col-sm-4 col-md-4">
							<div class="blok feature-item">
								<div class="image">
									<a href="services-detail.html" title=""><img src="/front_asset/images/about-3.jpg" alt="" class="img-responsive"></a>
								</div>
								<div class="item-body">
									<div class="description">
										<h5 class="blok-title">
											<a href="services-detail.html" title="">PEST PREVENTION</a>
										</h5>
										<p>Lorem ipsum dolor sit amet libero turpis non cras ligula id commodo aenean est in volutpat amet sodales porttitor bibendum facilisi.</p>
										
									</div>
									
								</div>
							</div>
						</div>
						
					</div>
				</div>
				
				<div class="col-sm-4 col-md-4">
					<div class="blok quotes">
						<div class="blok-title">
							<span>SCHEDULE</span> <br>A FREE INSPECTION
						</div>
						<form action="#" class="form-contact shake" id="contactForm"  data-toggle="validator">
							<div class="form-group">
								<input type="text" class="form-control" id="name" placeholder="Enter Name *" required>
								<div class="help-block with-errors"></div>
							</div>
							<div class="form-group">
								<input type="email" class="form-control" id="email" placeholder="Enter Email *" required>
								<div class="help-block with-errors"></div>
							</div>
							<div class="form-group">
								 <textarea id="message" class="form-control" rows="4" placeholder="Enter Your Message *" required></textarea>
								<div class="help-block with-errors"></div>
							</div>
							<div class="form-group">
								<div id="success"></div>
								<button type="submit" class="btn btn-default">ASK A QUOTE</button>
							</div>
						</form>
						<div class="icon"><span class="fa fa-calendar"></span></div>	
					</div>
				</div>
				
			</div>
		</div>
	</div>
	 
	<!-- PEST CONTROL -->
	<div class="section pest-control bgc">
		<div class="container">
		
			<div class="row">
				<div class="col-sm-6 col-md-6">
					<div class="section-title">
						<h3 class="lead">PEST CONTROL</h3>
					</div>
				</div>
				<div class="col-sm-6 col-md-6">
					<a href="#" title="" class="btn btn-default pull-right btn-view-all">VIEW ALL PEST CONTROL</a>
				</div>
			</div>
			
			<div class="row">
				
				<div class="col-sm-4 col-md-3">
					<div class="box-image">
						<div class="image">
							<a href="pest-control-detail.html" title=""><img src="/front_asset/images/pest-1.jpg" alt="" class="img-responsive"></a>
						</div>
						<div class="description">
							<h5 class="blok-title">
								<a href="pest-control-detail.html" title="">COCKROACH CONTROL</a>
							</h5>
						</div>
					</div>
				</div>
				<div class="col-sm-4 col-md-3">
					<div class="box-image">
						<div class="image">
							<a href="pest-control-detail.html" title=""><img src="/front_asset/images/pest-2.jpg" alt="" class="img-responsive"></a>
						</div>
						<div class="description">
							<h5 class="blok-title">
								<a href="pest-control-detail.html" title="">FLY CONTROL</a>
							</h5>
						</div>
					</div>
				</div>
				<div class="col-sm-4 col-md-3">
					<div class="box-image">
						<div class="image">
							<a href="pest-control-detail.html" title=""><img src="/front_asset/images/pest-3.jpg" alt="" class="img-responsive"></a>
						</div>
						<div class="description">
							<h5 class="blok-title">
								<a href="pest-control-detail.html" title="">YELLOW JACKET CONTROL</a>
							</h5>
						</div>
					</div>
				</div>
				<div class="col-sm-4 col-md-3">
					<div class="box-image">
						<div class="image">
							<a href="pest-control-detail.html" title=""><img src="/front_asset/images/pest-4.jpg" alt="" class="img-responsive"></a>
						</div>
						<div class="description">
							<h5 class="blok-title">
								<a href="pest-control-detail.html" title="">CARPENTER BEES CONTROL</a>
							</h5>
						</div>
					</div>
				</div>
				<div class="col-sm-4 col-md-3">
					<div class="box-image">
						<div class="image">
							<a href="pest-control-detail.html" title=""><img src="/front_asset/images/pest-5.jpg" alt="" class="img-responsive"></a>
						</div>
						<div class="description">
							<h5 class="blok-title">
								<a href="pest-control-detail.html" title="">MOSQUITO CONTROL</a>
							</h5>
						</div>
					</div>
				</div>
				<div class="col-sm-4 col-md-3">
					<div class="box-image">
						<div class="image">
							<a href="pest-control-detail.html" title=""><img src="/front_asset/images/pest-6.jpg" alt="" class="img-responsive"></a>
						</div>
						<div class="description">
							<h5 class="blok-title">
								<a href="pest-control-detail.html" title="">TERMITE CONTROL</a>
							</h5>
						</div>
					</div>
				</div>
				<div class="col-sm-4 col-md-3">
					<div class="box-image">
						<div class="image">
							<a href="pest-control-detail.html" title=""><img src="/front_asset/images/pest-7.jpg" alt="" class="img-responsive"></a>
						</div>
						<div class="description">
							<h5 class="blok-title">
								<a href="pest-control-detail.html" title="">ANT CONTROL</a>
							</h5>
						</div>
					</div>
				</div>
				<div class="col-sm-4 col-md-3">
					<div class="box-image">
						<div class="image">
							<a href="pest-control-detail.html" title=""><img src="/front_asset/images/pest-8.jpg" alt="" class="img-responsive"></a>
						</div>
						<div class="description">
							<h5 class="blok-title">
								<a href="pest-control-detail.html" title="">RODENT CONTROL</a>
							</h5>
						</div>
					</div>
				</div>
				
			</div>
		</div>
	</div>
	
	<!-- STATS -->
	<div class="section stats bg1">
		<div class="container">
		
			<div class="row">
				
				<div class="col-sm-4 col-md-3">
					<div class="box-stat">
						<div class="icon">
							<div class="fa fa-users"></div>
						</div>
						<h2 class="counter">1000+</h2>
						<p>Passionate Employee</p>
					</div>
				</div>
				
				<div class="col-sm-4 col-md-3">
					<div class="box-stat">
						<div class="icon">
							<div class="fa fa-building-o"></div>
						</div>
						<h2 class="counter">500+</h2>
						<p>Passionate Employee</p>
					</div>
				</div>
				
				<div class="col-sm-4 col-md-3">
					<div class="box-stat">
						<div class="icon">
							<div class="fa fa-heart-o"></div>
						</div>
						<h2 class="counter">320+</h2>
						<p>Passionate Employee</p>
					</div>
				</div>
				
				<div class="col-sm-4 col-md-3">
					<div class="box-stat">
						<div class="icon">
							<div class="fa fa-trophy"></div>
						</div>
						<h2 class="counter">24+</h2>
						<p>Passionate Employee</p>
					</div>
				</div>
				
			</div>
		</div>
	</div>
	
	<!-- WHY -->
	<div class="section why">
		<div class="container">
			<div class="row">	
				<div class="col-sm-8 col-md-8">
					<div class="row">
						<div class="col-sm-12 col-md-12">
							<div class="section-title">
								<h3 class="lead">WHY PEST RESOLVER?</h3>
							</div>
						</div>
						
					</div>
					
					<div class="row">
						<div class="col-sm-6 col-md-6">
							<div class="box-icon">
								<div class="icon">
									<div class="fa fa-clock-o"></div>
								</div>
								<div class="box-icon-body">
									<h5>ONE-TIME EXTERMINATION</h5>
									<p>Commodo enim aliquam suspendisse tortor cum diam commodo facilisis rutrum et duis nisl porttitor vel eleifend odio ultricies ut orci in adipiscing</p>
								</div>
							</div>
						</div>
						<div class="col-sm-6 col-md-6">
							<div class="box-icon">
								<div class="icon">
									<div class="fa fa-table"></div>
								</div>
								<div class="box-icon-body">
									<h5>MONTHLY MAINTENANCE</h5>
									<p>Commodo enim aliquam suspendisse tortor cum diam commodo facilisis rutrum et duis nisl porttitor vel eleifend odio ultricies ut orci in adipiscing</p>
								</div>
							</div>
						</div>
						<div class="col-sm-6 col-md-6">
							<div class="box-icon">
								<div class="icon">
									<div class="fa fa-briefcase"></div>
								</div>
								<div class="box-icon-body">
									<h5>FULL SERVICE PEST REMOVAL</h5>
									<p>Commodo enim aliquam suspendisse tortor cum diam commodo facilisis rutrum et duis nisl porttitor vel eleifend odio ultricies ut orci in adipiscing</p>
								</div>
							</div>
						</div>
						<div class="col-sm-6 col-md-6">
							<div class="box-icon">
								<div class="icon">
									<div class="fa fa-money"></div>
								</div>
								<div class="box-icon-body">
									<h5>COMPETITIVE PRICES</h5>
									<p>Commodo enim aliquam suspendisse tortor cum diam commodo facilisis rutrum et duis nisl porttitor vel eleifend odio ultricies ut orci in adipiscing</p>
								</div>
							</div>
						</div>
					</div>
					
				</div>
				<div class="col-sm-4 col-md-4">
					<div class="row">
						<div class="col-sm-12 col-md-12">
							<div class="section-title">
								<h3 class="lead">WHO WE ARE</h3>
							</div>
						</div>
						
					</div>
					
					<div class="row">
						<div class="col-sm-12 col-md-12">
							<div class="box-image-2">
								<div class="image animg">
									<img src="/front_asset/images/we-1.jpg" alt="" class="img-responsive">
								</div>
								<div class="box-image-body">
									<p>Commodo enim aliquam suspendisse tortor cum diam commodo facilisis rutrum et duis nisl porttitor vel eleifend odio ultricies ut orci in adipiscing</p>
								</div>
							</div>
							<div class="download-brochure">
								<a href="#" title="" class="btn btn-brochure">
									<span class="fa fa-file-pdf-o doc"></span>DOWNLOAD BROCHURE
									<span class="caret-brochure"></span>
								</a>
							</div>
						</div>
						
					</div>
					
				</div>
				
			</div>
		</div>
	</div>
	
	<!-- BLOG --> 
	<div class="section blog bgc">
		<div class="container">
		
			<div class="row">
				<div class="col-sm-6 col-md-6">
					<div class="section-title">
						<h3 class="lead">COMPANY NEWS</h3>
					</div>
				</div>
				<div class="col-sm-6 col-md-6">
					<a href="#" title="" class="btn btn-default pull-right btn-view-all">VIEW ALL NEWS</a>
				</div>
			</div>
			
			<div class="row">
				
				<div class="col-sm-4 col-md-4">
					<div class="blog-item">
						<div class="gambar">
							<img src="/front_asset/images/blog-1.jpg" alt="" class="img-responsive">
						</div>
						<div class="item-body">
							<div class="metadate">
								<div class="month">AUG</div>
								<div class="date">14, 2016</div>
							</div>
							<div class="description">
								<h4>
									<a href="blog-detail.html" title="">Heading of Blog</a>
								</h4>
								<p class="postby">
									by <a href="#" title="">Admin</a> <span>/</span> 3 <a href="#" title="">Comments</a>
								</p>
								<p>Lorem ipsum dolor sit amet libero turpis non cras ligula id commodo aenean est in volutpat amet sodales porttitor bibendum facilisi suspendisse aliquam ipsum ante morbi sed ipsum mollis. Sollicitudin viverra vel varius eget sit mollis.</p>
							</div>
							
						</div>
					</div>
				</div>
				
				<div class="col-sm-4 col-md-4">
					<div class="blog-item">
						<div class="gambar">
							<img src="/front_asset/images/blog-2.jpg" alt="" class="img-responsive">
						</div>
						<div class="item-body">
							<div class="metadate">
								<div class="month">AUG</div>
								<div class="date">14, 2016</div>
							</div>
							<div class="description">
								<h4>
									<a href="blog-detail.html" title="">Heading of Blog</a>
								</h4>
								<p class="postby">
									by <a href="#" title="">Admin</a> <span>/</span> 3 <a href="#" title="">Comments</a>
								</p>
								<p>Lorem ipsum dolor sit amet libero turpis non cras ligula id commodo aenean est in volutpat amet sodales porttitor bibendum facilisi suspendisse aliquam ipsum ante morbi sed ipsum mollis. Sollicitudin viverra vel varius eget sit mollis.</p>
							</div>
							
						</div>
					</div>
				</div>
				
				<div class="col-sm-4 col-md-4">
					<div class="blog-item">
						<div class="gambar">
							<img src="/front_asset/images/blog-3.jpg" alt="" class="img-responsive">
						</div>
						<div class="item-body">
							<div class="metadate">
								<div class="month">AUG</div>
								<div class="date">14, 2016</div>
							</div>
							<div class="description">
								<h4>
									<a href="blog-detail.html" title="">Heading of Blog</a>
								</h4>
								<p class="postby">
									by <a href="#" title="">Admin</a> <span>/</span> 3 <a href="#" title="">Comments</a>
								</p>
								<p>Lorem ipsum dolor sit amet libero turpis non cras ligula id commodo aenean est in volutpat amet sodales porttitor bibendum facilisi suspendisse aliquam ipsum ante morbi sed ipsum mollis. Sollicitudin viverra vel varius eget sit mollis.</p>
							</div>
							
						</div>
					</div>
				</div>
				
			</div>
		</div>
	</div>
	
	<!-- TESTIMONY --> 
	<div class="section testimony bgi-2">
		<div class="container">
		
			<div class="row">
				<div class="col-sm-12 col-md-12">
					<div class="section-title center cwhite">
						<h3 class="lead">TESTIMONIALS</h3>
					</div>
				</div>
			</div>
			
			<div class="row">
				
				<div class="col-sm-12 col-md-12">
					<div id="owl-testimony">
						<div class="item">
							<div class="item-testimony">
								<div class="quote-box">
									<blockquote class="quote">
									 We specialize in 23 different kinds of pest, and we're also qualified to handle a much wider range of pest control needs. If you have a pest problem that's not covered in our pest library, be sure to contact us for information about what services we offer for your particular needs.If you have a pest problem that's not covered in our pest library, be sure to contact us for information about what services we offer for your particular needs.
									</blockquote>
								</div>
								<div class="people">
									<img class="img-rounded user-pic" src="/front_asset/images/testimony-thumb-1.jpg" alt="">
									<p class="details">
										Johnathan Doel <span>CEO Buka Kreasi</span>
									</p>                        
								</div>
								<div class="icon"><span class="fa fa-quote-left"></span></div>
							</div>
						</div>
						<div class="item">
							<div class="item-testimony">
								<div class="quote-box">
									<blockquote class="quote">
									 Smart Template - libero turpis non cras ligula id commodo aenean est in volutpat amet sodales porttitor bibendum facilisi suspendisse aliquam ipsum ante morbi sed ipsum mollis.
									</blockquote>
								</div>
								<div class="people">
									<img class="img-rounded user-pic" src="/front_asset/images/testimony-thumb-2.jpg" alt="">
									<p class="details">
										Johnathan Doel <span>CEO Buka Kreasi</span>
									</p>                        
								</div>
								<div class="icon"><span class="fa fa-quote-left"></span></div>
							</div>
						</div>
						<div class="item">
							<div class="item-testimony">
								<div class="quote-box">
									<blockquote class="quote">
									 Smart Template - libero turpis non cras ligula id commodo aenean est in volutpat amet sodales porttitor bibendum facilisi suspendisse aliquam ipsum ante morbi sed ipsum mollis.
									</blockquote>
								</div>
								<div class="people">
									<img class="img-rounded user-pic" src="/front_asset/images/testimony-thumb-3.jpg" alt="">
									<p class="details">
										Johnathan Doel <span>CEO Buka Kreasi</span>
									</p>                        
								</div>
								<div class="icon"><span class="fa fa-quote-left"></span></div>
							</div>
						</div>
						<div class="item">
							<div class="item-testimony">
								<div class="quote-box">
									<blockquote class="quote">
									 Smart Template - libero turpis non cras ligula id commodo aenean est in volutpat amet sodales porttitor bibendum facilisi suspendisse aliquam ipsum ante morbi sed ipsum mollis.
									</blockquote>
								</div>
								<div class="people">
									<img class="img-rounded user-pic" src="/front_asset/images/testimony-thumb-4.jpg" alt="">
									<p class="details">
										Johnathan Doel <span>CEO Buka Kreasi</span>
									</p>                        
								</div>
								<div class="icon"><span class="fa fa-quote-left"></span></div>
							</div>
						</div>
						<div class="item">
							<div class="item-testimony">
								<div class="quote-box">
									<blockquote class="quote">
									 Smart Template - libero turpis non cras ligula id commodo aenean est in volutpat amet sodales porttitor bibendum facilisi suspendisse aliquam ipsum ante morbi sed ipsum mollis.
									</blockquote>
								</div>
								<div class="people">
									<img class="img-rounded user-pic" src="/front_asset/images/testimony-thumb-5.jpg" alt="">
									<p class="details">
										Johnathan Doel <span>CEO Buka Kreasi</span>
									</p>                        
								</div>
								<div class="icon"><span class="fa fa-quote-left"></span></div>
							</div>
						</div>
						<div class="item">
							<div class="item-testimony">
								<div class="quote-box">
									<blockquote class="quote">
									 Smart Template - libero turpis non cras ligula id commodo aenean est in volutpat amet sodales porttitor bibendum facilisi suspendisse aliquam ipsum ante morbi sed ipsum mollis.
									</blockquote>
								</div>
								<div class="people">
									<img class="img-rounded user-pic" src="/front_asset/images/testimony-thumb-6.jpg" alt="">
									<p class="details">
										Johnathan Doel <span>CEO Buka Kreasi</span>
									</p>                        
								</div>
								<div class="icon"><span class="fa fa-quote-left"></span></div>
							</div>
						</div>
						<div class="item">
							<div class="item-testimony">
								<div class="quote-box">
									<blockquote class="quote">
									 Smart Template - libero turpis non cras ligula id commodo aenean est in volutpat amet sodales porttitor bibendum facilisi suspendisse aliquam ipsum ante morbi sed ipsum mollis.
									</blockquote>
								</div>
								<div class="people">
									<img class="img-rounded user-pic" src="/front_asset/images/testimony-thumb-7.jpg" alt="">
									<p class="details">
										Johnathan Doel <span>CEO Buka Kreasi</span>
									</p>                        
								</div>
								<div class="icon"><span class="fa fa-quote-left"></span></div>
							</div>
						</div>
						<div class="item">
							<div class="item-testimony">
								<div class="quote-box">
									<blockquote class="quote">
									 Smart Template - libero turpis non cras ligula id commodo aenean est in volutpat amet sodales porttitor bibendum facilisi suspendisse aliquam ipsum ante morbi sed ipsum mollis.
									</blockquote>
								</div>
								<div class="people">
									<img class="img-rounded user-pic" src="/front_asset/images/testimony-thumb-4.jpg" alt="">
									<p class="details">
										Johnathan Doel <span>CEO Buka Kreasi</span>
									</p>                        
								</div>
								<div class="icon"><span class="fa fa-quote-left"></span></div>
							</div>
						</div>
					</div>
					
				</div>

				
			</div>
		</div>
	</div>
	
	
	
	<!-- CTA -->
	<div class="section cta">
		<div class="container">
			
			<div class="row">
				
				<div class="col-sm-12 col-md-12">
					<div class="wrap-cta">
						<div class="cta-img">
							<img src="/front_asset/images/img-cta.png" alt="" />
						</div>
						<div class="cta-desc">
							<p>Have Any Question!</p>
							<h3>DON'T HESITATE TO CONTACT US ANY TIME.</h3>
						</div>
						<a href="contact.html" title="" class="btn btn-contact pull-right btn-view-all">CONTACT US</a>
					</div>
				</div>

			</div>
		</div>
	</div>

@endsection
