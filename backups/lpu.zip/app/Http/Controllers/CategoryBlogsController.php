<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CategoryBlogsController extends Controller
{
    //
}
